// 路由配置
export const ROUTE_NAME_CONFIG = {
  Login: 'login',
  Main: 'main'
}
