<script setup lang="ts"></script>

<template>
  <div class="view-main">
    <img class="inline" alt="Vue logo" src="@/assets/logo.png" />
    <svg-icon name="pen" />
    <el-button>自动引入一个Elment-Button</el-button>
    <HelloWorld msg="Hello Vue 3 + TypeScript + Vite" />
  </div>
</template>

<style lang="scss" scoped>
.view-main {
  margin-top: 60px;
  text-align: center;
}
</style>
